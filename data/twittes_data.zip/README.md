# Dataset comentários toxicos PT-BR
O dataset construído a partir de outros em português encontrados na internet. Os dados foram padronizados e também inclui uma coluna contendo a normalização dos textos.
O csv está estruturado da seguinte forma:
* text: o comentário sem pré-processamento
* text_norm: comentário sem emojis, stop words e normalizado
* toxic: 1 para comentário tóxico e 0 para não tóxico 
